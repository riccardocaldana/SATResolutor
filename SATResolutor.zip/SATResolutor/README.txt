Requirements:
java:[ ubuntu 'sudo apt-get install openjdk-7-jdk' ]
ant: [ubuntu 'sudo apt-get install ant']

Build:
To build the entire project, just run ant in the root directory (that contains build.xml)

Run:
To run the project move in the jar folder and then launch the command 
java -jar solutore_sat_cdcl.jar
or
java -jar -Xss515m solutore_sat_cdcl.jar if you want more stack for
your execution.

Interaction:
you can interact with the program in these different ways: (i- :interface commands)
Test files are in "files" directory so the correct path is "../files/<filename>.cnf"

1) Pigeonhole problem:
SOLUTORE SAT CDCL
i-Si desidera sottomettere un'istanza del Pigeonhole problem? (s/n)
-s
i-Inserire n:
-1 (for example)
i-Si desidera la stampa della prova? (s/n)
-s (for example)

2) Other cnf files:
SOLUTORE SAT CDCL 
i-Si desidera sottomettere un'istanza del Pigeonhole problem? (s/n)
-n
i-Si desidera sottomettere un file contenente il problema? (s/n)
-s
i-Inserisci il nome del file di Input: 
-../files/uf20-01.cnf (for example)
i-Si desidera la stampa della prova? (s/n)
-s (for example)

3) Writing your own cnf file by stdin:
SOLUTORE SAT CDCL
i-Si desidera sottomettere un'istanza del Pigeonhole problem? (s/n)
-n
i-Si desidera sottomettere un file contenente il problema? (s/n)
-n
i-Si è scelto di procedere alla scrittura manuale di un insieme di clausole cnf
i-Inserire numero di variabili
-2 (for example)
i-Inserire numero di clausole
-1 (for example)
i-inserire i letterali della clausola 1 (la clausola termina inserendo uno 0)
-1 2 0 (for example)
i-Si desidera la stampa della prova? (s/n)
-s (for example)
