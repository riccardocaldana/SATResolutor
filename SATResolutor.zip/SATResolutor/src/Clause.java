import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Clause {
    private int number;
    private Boolean satisfied;
    private Set<Literal> set;
    private Set<Literal> trueLiterals;
    private Set<Literal> falseLiterals;
    private Literal assertionLiteral;
    private int size;
    private ArrayList<Literal> watchedLiterals; // i primi due letterali della clausola sono sentinelle

    public Clause(int number,Set<Literal> set){
        this.number=number;
        this.satisfied=false;
        this.set=new HashSet<>();
        this.set.addAll(set);
        this.size=this.set.size();
        this.satisfied=false;
        this.trueLiterals=new HashSet<>();
        this.falseLiterals=new HashSet<>();
        this.watchedLiterals=new ArrayList<>();
        if(this.size>1){
            int i=0;
            for(Literal l:this.set) {
                if (i < 2) {
                    this.watchedLiterals.add(l);
                    l.getWatchedList().add(this);
                    i++;

                } else break;
            }
        }
        else this.watchedLiterals=null;
        this.assertionLiteral=null;

    }

    public void setAssertionLiteral(Literal assertionLiteral) {
        this.assertionLiteral = assertionLiteral;
    }

    public Literal getAssertionLiteral() {
        return assertionLiteral;
    }

    public ArrayList<Literal> getWatchedLiterals() {
        return watchedLiterals;
    }

    public Set<Literal> getFalseLiterals() {
        return falseLiterals;
    }

    public Set<Literal> getTrueLiterals() {
        return trueLiterals;
    }

    public int getSize() {
        return size;
    }

    public void setSatisfied(Boolean satisfied) {
        this.satisfied = satisfied;
    }

    public int getNumber() {
        return number;
    }

    public Boolean getSatisfied() {
        return satisfied;
    }

    public Set<Literal> getSet() {
        return set;
    }

    @Override
    public int hashCode() {
        return number;
    }

    @Override
    public boolean equals(Object obj) { //&& set.containsAll(((Clause) obj).getSet())
        return obj instanceof Clause && number==((Clause) obj).number && set.containsAll(((Clause) obj).getSet()) && this.size==((Clause) obj).size && this.satisfied==((Clause) obj).satisfied;
    }
    public boolean isSubset(Clause c){
        for(Literal l:set){
            if(!c.getSet().contains(l)) return false;
        }
        return true;
    }
    @Override
    public String toString() {
        String result="";
        for(Literal l:set){
            result+=l.toString()+" ";
        }
        //result+="\n watchedLiterals: ";
        /*if(this.watchedLiterals!=null)
            for(Literal l:watchedLiterals){
                result+=l.toString()+ " ";
            }*/
        return result;
    }
}
