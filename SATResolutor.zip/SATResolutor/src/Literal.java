import java.util.ArrayList;

public class Literal implements Comparable<Literal>{
    private int number;
    private int state; // 0 undefined, 1 true, -1 false
    private int count; //contatore per VSIDS
    private Clause justification;
    private ArrayList<Clause> watchedList;
    public Literal(int number, int state){
        this.number=number;
        this.state=0;
        this.count=0;
        this.watchedList=new ArrayList<>();
    }

    public ArrayList<Clause> getWatchedList() {
        return watchedList;
    }

    public void setJustification(Clause justification) {
        this.justification = justification;
    }

    public Clause getJustification() {
        return justification;
    }

    public void setState(int state) {
        this.state = state;
    }
    public void updatecount(){
        this.count++;
    }

    public int getCount() {
        return count;
    }

    public int getState() {
        return state;
    }
    public void divisionCount(){
        this.count=this.count/2;
    }
    public int getNumber() {
        return number;
    }

    @Override
    public int hashCode() {
        return number;
    }
    @Override
    public boolean equals(Object obj) {
        return obj instanceof Literal && number==((Literal) obj).number;
    }

    @Override
    public String toString() {
        return Integer.toString(number);
    }

    @Override
    public int compareTo(Literal o) {
        if(this.count==o.count) return 0;
        else if(this.count>o.count) return -1;
        return 1;
    }
}
