import java.util.Scanner;
import java.io.*;

public class Main {

    public static void main(String[] args) {
        try {
            File file;
            Scanner input = new Scanner(System.in);
            System.out.println("SOLUTORE SAT CDCL");
            System.out.println("Si desidera sottomettere un'istanza del Pigeonhole problem? (s/n)");
            String ans = input.nextLine();
            String proof;
            if (ans.equals("s")) {
                System.out.println("Inserire n: ");
                ans = input.nextLine();
                file = new File("pig" + ans + ".cnf");
                System.out.println("Si desidera la stampa della prova? (s/n)");
                proof = input.nextLine();
                pigeonhole(Integer.parseInt(ans), file);
                Input in = new Input(file);
                in.readFile();
                Procedure procedure1 = new Procedure(in.getProblem(), proof);
                Test test = new Test(in.getProblem());
                procedure1.setTest(test);
                procedure1.zeroPropagation();
            } else {
                System.out.println("Si desidera sottomettere un file contenente il problema? (s/n)");
                ans = input.nextLine();
                if (ans.equals("s")) {
                    System.out.println("Inserisci il nome del file di Input: ");
                    String fileName = input.nextLine();
                    file = new File(fileName);
                    Input in = new Input(file);
                    in.readFile();
                    System.out.println("Si desidera la stampa della prova? (s/n)");
                    proof = input.nextLine();
                    Procedure procedure = new Procedure(in.getProblem(), proof);
                    Test test = new Test(in.getProblem());
                    procedure.setTest(test);
                    procedure.zeroPropagation();
                } else {
                    System.out.println("Si è scelto di procedere alla scrittura manuale di un insieme di clausole cnf");
                    file = new File("mySet" + ".cnf");
                    System.out.println("Inserire numero di variabili");
                    int nVar = input.nextInt();
                    System.out.println("Inserire numero di clausole");
                    int nCla = input.nextInt();
                    int i = 1;
                    int let = 1;
                    try (PrintWriter writer = new PrintWriter(file.getName())) {
                        writer.println("p cnf " + nVar + " " + nCla);
                        while (i <= nCla) {
                            System.out.println("inserire i letterali della clausola " + Integer.toString(i) + " (la clausola termina inserendo uno 0)");
                            while (let != 0) {
                                let = input.nextInt();
                                if (let > nVar) {
                                    System.out.println("Errore, i letterali vanno da 1 a nVariabili");
                                } else {
                                    writer.print(let + " ");

                                }
                            }
                            writer.println("");
                            i++;
                            let = 1;
                        }
                        writer.close();
                        Input in = new Input(file);
                        in.readFile();
                        System.out.println("Si desidera la stampa della prova? (s/n)");
                        proof = input.next();
                        Procedure procedure = new Procedure(in.getProblem(), proof);
                        Test test = new Test(in.getProblem());
                        procedure.setTest(test);

                        procedure.zeroPropagation();
                    } catch (FileNotFoundException e) {
                        System.out.println("Errore, file non trovato");
                    }

                }

            }
        }
        catch(StackOverflowError e){
            System.out.println("Errore");
        }


    }
    private static void pigeonhole(int n, File file){
        try (PrintWriter writer = new PrintWriter(file.getName())) {
            int nC=(n+1)+n*(n*(n+1)/2);
            int nV=n*(n+1);
            writer.println("p cnf "+Integer.toString(nV)+" "+Integer.toString(nC));
            //ogni oggetto è in un buco n+1 clausole
            String string="";
            int m;
            for(int i=1;i<=nV;i=i+n){
                m=i;
                for(int j=1;j<=n;j++) {
                    string += Integer.toString(m) + " ";
                    m++;
                }
                writer.println(string+" 0");
                string="";
            }

            //ogni buco contiene solo un oggetto
            int k=1;
            while(k<=n) {
                for (int i = k; i <= nV - n; i = i + n) {
                    for (int j = i + n; j <= nV; j = j + n) {
                        writer.println(Integer.toString(-i)+" "+Integer.toString(-j)+" 0");
                    }
                }
                k++;
            }
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }
}
