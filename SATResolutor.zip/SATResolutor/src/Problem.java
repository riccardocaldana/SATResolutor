import java.util.HashSet;
import java.util.Set;

public class Problem {
    private Set<Literal> setL;
    private Set<Clause> setC; // non soddisfatte
    private Set<Clause> sat; // soddisfatte
    private int numVariables;
    private int numClauses;
    private int numClausesTot; //conta anche giustificazioni per dare numero diversi alle clausole
    private Set<Clause> temp = new HashSet<>();
    private Set<Clause> tempSat = new HashSet<>();

    public Problem() {
        this.sat = new HashSet<>();
    }

    public void subsumption() {
        temp.clear();
        tempSat.clear();
        temp.addAll(setC);
        tempSat.addAll(sat);
        for (Clause c : setC) {
            for (Clause c1 : setC) {
                if (!c.equals(c1)) {
                    if (c.isSubset(c1) && temp.contains(c1) && temp.contains(c)) {
                        //rimuovo c dall'insieme
                        temp.remove(c1);
                        tempSat.remove(c1);
                        this.numClauses = this.numClauses - 1;
                        this.numClausesTot = this.numClausesTot - 1;
                    }
                }
            }
        }
        setC.clear();
        setC.addAll(temp);
        sat.clear();
        sat.addAll(tempSat);
    }

    public void setSetC(Set<Clause> setC) {
        this.setC = new HashSet<>();
        this.setC.addAll(setC);
    }

    public void setSetL(Set<Literal> setL) {
        this.setL = new HashSet<>();
        this.setL.addAll(setL);
    }

    public Set<Clause> getSat() {
        return sat;
    }

    public void updateNumClauses() {
        numClauses++;
    }

    public int getNumClauses() {
        return numClauses;
    }

    public int getNumVariables() {
        return numVariables;
    }

    public void setNumClauses(int numClauses) {
        this.numClauses = numClauses;
        this.numClausesTot = numClauses;
    }

    public int getNumClausesTot() {
        return numClausesTot;
    }

    public void updateNumClausesTot() {
        this.numClausesTot = this.numClausesTot + 1;
    }

    public void setNumVariables(int numVariables) {
        this.numVariables = numVariables;
    }

    public Set<Clause> getSetC() {
        return setC;
    }

    public Set<Literal> getSetL() {
        return setL;
    }

    public Literal getLiteral(int number) {
        for (Literal l : setL) {
            if (l.getNumber() == number) return l;
        }
        return null;
    }

    @Override
    public String toString() {
        String result = "";
        for (Clause c : setC) {
            result += c.toString() + "\n";
        }
        return result;
    }

}
