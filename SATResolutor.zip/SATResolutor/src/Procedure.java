import java.util.*;


public class Procedure{
    private Problem problem;
    private Trace trace;
    private Queue<Literal> propagatedLiterals;
    private boolean propagationFlag;
    private Integer currentLevel;
    private int numConflict=0;
    private ArrayList<Literal> a=new ArrayList<>();
    private Test test;
    private boolean proof;
    private int numLearned=0;
    private ArrayList<Clause> tempList=new ArrayList<>();
    private int level;
    private int numLearnedTot=0;
    private int numConflictTot=0;

    public Procedure(Problem problem,String proof) {
        this.problem = problem;
        this.trace = new Trace();
        this.propagatedLiterals = new LinkedList<>();
        propagationFlag = false;
        currentLevel = 0;
        if(proof.equals("s")) this.proof=true;
        Literal[] array=problem.getSetL().toArray(new Literal[problem.getSetL().size()]);
        a.addAll(Arrays.asList(array));
        Collections.sort(a);
        problem.subsumption();
    }

    public void setTest(Test test) {
        this.test = test;
    }

    //Propagazione livello 0
    public void zeroPropagation() {
        LinkedList<Literal> temp1 = new LinkedList<>(); // lista da letterali al livello 0, tutte le clausole unitarie non in conflitto
        for (Clause c : problem.getSetC()) {
            if (c.getSize() == 1) { // per ogni clausola unitaria, metto il letterale a vero per soddisfarla al livello 0 della traccia
                for (Literal l : c.getSet()) { //uno solo
                    if (l.getState() == 0) { //se è indefinito
                        l.setState(1); //lo rendo vero
                        l.setJustification(c);
                        temp1.add(l);
                        //soddisfo tutte le clausole che lo contengono
                        satClauses(l);
                        setNegationLiteral(l);
                        Literal l2 = problem.getLiteral(-l.getNumber());
                        l2.setState(-1); //rendo falso il letterale negato
                        for (Clause c2 : problem.getSetC()) {
                            if (c2.getSet().contains(l2)) {
                                c2.getFalseLiterals().add(l2); //l2 è falso
                                if (c2.getSize() == 1) {
                                    if(proof){
                                        printEmpty(c2);
                                    }
                                    System.out.println("INSODDISFACIBILE");
                                    //System.out.println("Numero di clausole imparate: "+numLearnedTot);
                                    //System.out.println("Numero di conflitti: "+numConflictTot);
                                    System.exit(0);
                                } else {
                                    if (!propagatedLiterals.contains(l2))
                                        propagatedLiterals.add(l2); //l2 deve essere propagato
                                    propagationFlag = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        if(!temp1.isEmpty())
            trace.getTrace().put(0, temp1);
        if (propagationFlag){
            propagationFlag=false;
            propagation();
        }
        if (problem.getSat().size() == problem.getNumClauses()) {
            System.out.println("SODDISFACIBILE");
            System.out.println(printModel());
            //System.out.println("Numero di clausole imparate: "+numLearnedTot);
            //System.out.println("Numero di conflitti: "+numConflictTot);
            //test.setTrace(trace);
            //test.sat();
            System.exit(0);
        }
        else{
            decision();
        }
    }

    private void decision() { // vsids
        if (problem.getSat().size() == problem.getNumClauses()) {
            System.out.println("SODDISFACIBILE");
            System.out.println(printModel());
            //System.out.println("Numero di clausole imparate: "+numLearnedTot);
            //System.out.println("Numero di conflitti: "+numConflictTot);
            //test.setTrace(trace);
            //test.sat();
            System.exit(0);
        }

        LinkedList<Literal> temp=new LinkedList<>();
        for(Literal l:a){
            if(l.getState()==0) {
                l.setState(1);
                currentLevel = currentLevel + 1;
                temp.add(l);
                trace.getTrace().put(currentLevel, temp);
                satClauses(l);
                Literal negation = setNegationLiteral(l);
                propagatedLiterals.add(negation);
                propagationFlag = true;
                break;
            }
        }

        if(propagationFlag){
            propagationFlag=false;
            propagation();
        }
        decision();
    }

    private void divisionCounts() {
        for(Literal l: problem.getSetL()){
            l.divisionCount();
        }
        numConflict=0;
    }

    private void propagation() {
        boolean find = false;
        while (!propagatedLiterals.isEmpty()) {
            Literal l1 = propagatedLiterals.remove();
            tempList.clear();
            tempList.addAll(l1.getWatchedList());
            for (Clause c : tempList) {
                find=false;
                if(c.getSatisfied()) continue;
                if (problem.getSat().size() == problem.getNumClauses()) {
                    System.out.println("SODDISFACIBILE");
                    System.out.println(printModel());
                    //System.out.println("Numero di clausole imparate: "+numLearnedTot);
                    //System.out.println("Numero di conflitti: "+numConflictTot);
                    //test.setTrace(trace);
                    //test.sat();
                    System.exit(0);
                }
                if (c.getSize() == 1) continue;

                Literal w1 = c.getWatchedLiterals().get(0);
                Literal w2 = c.getWatchedLiterals().get(1);
                if (l1.equals(w2)) { // li inverto
                    Literal temp = w1;
                    w1 = w2;
                    w2 = temp;
                }

                if (l1.equals(w1) && w2.getState() == 1) { //l1 diventa falso e l2 è vero, cerco un altro letterale sentinella
                    for (Literal l3 : c.getSet()) {
                        if ((!l3.equals(w2)) && (l3.getState() == 0 || l3.getState() == 1)) { // l3 è indefinito
                            c.getWatchedLiterals().add(l3); // aggiungo l3
                            l3.getWatchedList().add(c);
                            c.getWatchedLiterals().remove(w1);// rimuovo l1
                            l1.getWatchedList().remove(c);
                            break;
                        }
                    }
                } else if (l1.equals(w1) && w2.getState() == 0) { //l2 è indefinito
                    for (Literal l3 : c.getSet()) { // cerco l3
                        if (!l3.equals(w2) && (l3.getState() == 0 || l3.getState() == 1)) {
                            c.getWatchedLiterals().add(l3); // aggiungo l3
                            l3.getWatchedList().add(c);
                            c.getWatchedLiterals().remove(w1);// rimuovo l1
                            l1.getWatchedList().remove(c);
                            find = true;
                            break;
                        }
                    }
                    if (!find) {
                        //l2 è implicato, lo setto vero e lo aggiungo alla traccia con giustificazione c
                        w2.setState(1);
                        w2.setJustification(c);
                        LinkedList<Literal> temp = trace.getTrace().get(currentLevel);
                        temp.add(w2);
                        trace.getTrace().remove(currentLevel);
                        trace.getTrace().put(currentLevel,temp);
                        satClauses(w2);
                        // -l2 è falso, devo propagare anche lui se necessario
                        Literal negation = setNegationLiteral(w2);
                        propagatedLiterals.add(negation);
                    }
                } else if (l1.equals(w1) && w2.getState() == -1) {//l1 e l2 entrambi falsi, cerco due sentinelle
                    boolean first=false;
                    boolean second=false;
                    Literal a=null;
                    Literal b=null;
                    for (Literal l3 : c.getSet()) { // cerco l3
                        if(first || second ) break;
                        if ((l3.getState() == 0 || l3.getState() == 1)) {
                            c.getWatchedLiterals().add(l3); // aggiungo l3
                            l3.getWatchedList().add(c);
                            c.getWatchedLiterals().remove(w1);// rimuovo l1
                            l1.getWatchedList().remove(c);
                            first = true;
                            a=l3;
                            for (Literal l4 : c.getSet()) { //cerco l4
                                if (!l4.equals(l3) && (l4.getState() == 0 || l4.getState() == 1)) {
                                    c.getWatchedLiterals().add(l4); // aggiungo l4
                                    l4.getWatchedList().add(c);
                                    c.getWatchedLiterals().remove(w2);// rimuovo l2
                                    w2.getWatchedList().remove(c);
                                    second = true;
                                    b=l4;
                                    break;
                                }
                            }
                        }
                    }
                    if (first && second) {
                        first=false;
                        second=false;
                    }
                    else if (first) { // l3 è implicato
                        first=false;
                        a.setState(1);
                        a.setJustification(c);
                        LinkedList<Literal> temp = trace.getTrace().get(currentLevel);
                        temp.add(a);
                        trace.getTrace().remove(currentLevel);
                        trace.getTrace().put(currentLevel, temp);
                        satClauses(a);
                        // -l2 è falso, devo propagare anche lui se necessario
                        Literal negation = setNegationLiteral(a);
                        propagatedLiterals.add(negation);
                        //break;
                    } else { //conflitto
                        conflict(c);
                        break;
                    }
                    find=false;
                }
            }
            tempList.clear();
            //for(Clause deleted: toDelete){
            //    l1.getWatchedList().remove(deleted);
            //}
        }
    }

    private void satClauses(Literal l) {

            //soddisfo tutte le clausole che lo contengono
            for (Clause c1 : problem.getSetC()) {
                if (c1.getSet().contains(l)) {
                    c1.getTrueLiterals().add(l); //lo aggiungo ai letterali che la rendono vera
                    c1.getFalseLiterals().remove(l);
                    c1.setSatisfied(true); // la soddisfo
                    if (!problem.getSat().contains(c1))
                        problem.getSat().add(c1); // aggiungo la clausola a quelle soddisfatte
                }

            }


    }

    private Literal setNegationLiteral(Literal l) {
        int count=0;
        Literal l2 = problem.getLiteral(-l.getNumber());
        l2.setState(-1); //rendo falso il letterale negato
        for (Clause c2 : problem.getSetC())
            if (c2.getSet().contains(l2)){
                c2.getFalseLiterals().add(l2); //l2 è falso
                c2.getTrueLiterals().remove(l2);
                if(c2.getTrueLiterals().size()==0){
                    c2.setSatisfied(false); // c2 non è soddisfatta
                    problem.getSat().remove(c2);
                    for(Literal lit: c2.getWatchedLiterals()){
                        lit.getWatchedList().remove(c2);
                    }
                    c2.getWatchedLiterals().clear();
                    count=0;
                    while(count<2){
                        for(Literal l1:c2.getSet()){
                            if(count < 2 && (l1.getState()==0 || l1.getState()==1)){
                                c2.getWatchedLiterals().add(l1);
                                l1.getWatchedList().add(c2);
                                count++;
                            }
                        }
                        if(c2.getWatchedLiterals().size()!=2) {
                            c2.getWatchedLiterals().add(l2);
                            l2.getWatchedList().add(c2);
                            count++;
                            for (Literal l3 : c2.getFalseLiterals()) {
                                if (count < 2) {
                                    c2.getWatchedLiterals().add(l3);
                                    l3.getWatchedList().add(c2);
                                    count++;
                                }
                            }
                        }
                    }
                }
            }
        return l2;
    }

    private void conflict(Clause conflictClause) {
        numConflict++;
        numConflictTot++;
        if(numConflict==4)
            divisionCounts();
        if(proof)
            System.out.println("Conflitto: "+conflictClause.toString());
        assert conflictClause != null;
        while(!isAssertionClause(conflictClause)){
            conflictClause=explain(conflictClause); // spiegazione per risoluzione
        }
        if(proof)
            System.out.println("Asserzione: "+conflictClause.toString());
        learning(conflictClause); //apprendimento della prima clausola di asserzione

    }

    private boolean isAssertionClause(Clause c){
        ArrayList<Literal> temp=new ArrayList<>();
        int count=0;
        for(Literal l:c.getSet()){
            if(trace.getTrace().get(currentLevel).contains(problem.getLiteral(-l.getNumber()))){ //il letterale è reso falso al livello corrente
                count++;
                temp.add(l);
            }
        }
        if(temp.size()==1){
            for(Literal l: temp){
                l.setJustification(c);
                c.setAssertionLiteral(l);
            }
        }
        return count==1;
    }

    private void learning(Clause c){
        numLearned=numLearned+1;
        numLearnedTot++;
        if(currentLevel==0){
            //non apprendo la clasusola di asserzione al livello 0
            Clause c1;
            for(Clause c2: problem.getSetC()){
                if(c2.getSet().size()==1){
                    for(Literal l1:c2.getSet()){
                        if(l1.equals(problem.getLiteral(-c.getAssertionLiteral().getNumber()))){
                            if(proof)
                                System.out.println(printEmpty(c));
                            System.out.println("INSODDISFACIBILE");
                            //System.out.println("Numero di clausole imparate: "+numLearnedTot);
                            //System.out.println("Numero di conflitti: "+numConflictTot);
                            System.exit(0);
                        }
                    }
                }
            }
            c1=explain(c);
            for(Literal l:c1.getSet())
                c1.setAssertionLiteral(l);
            if(c1.getAssertionLiteral()!=null)
                if(proof)
                    System.out.println(printEmpty(c1));
            else if(proof)
                    System.out.println(printEmpty(c));
            System.out.println("INSODDISFACIBILE");
            //System.out.println("Numero di clausole imparate: "+numLearnedTot);
            //System.out.println("Numero di conflitti: "+numConflictTot);
            System.exit(0);
        }
        else{
            //debug
            for(Clause clause: problem.getSetC()){
                if(clause.getSet().size()==c.getSet().size() && clause.getSet().containsAll(c.getSet())){
                    System.out.println("Apprendo stessa clausola!");
                    System.exit(1);
                }
            }
            problem.getSetC().add(c);
            problem.updateNumClauses();

            if(problem.getNumClauses()!=problem.getSetC().size()){
                problem.setNumClauses(problem.getSetC().size());
            }
            updateCounts(c);
        }
        if(numLearned==10) {
            Collections.sort(a);
            numLearned=0;
        }
        backJumping(c);
        if (problem.getSat().size() == problem.getNumClauses()) {
            System.out.println("SODDISFACIBILE");
            System.out.println(printModel());
            //System.out.println("Numero di clausole imparate: "+numLearnedTot);
            //System.out.println("Numero di conflitti: "+numConflictTot);
            //test.setTrace(trace);
            //test.sat();
            System.exit(0);
        }
        if (propagationFlag){
            propagationFlag=false;
            propagation();
        }

        decision();

    }


    private void updateCounts(Clause c) {
        for(Literal l:c.getSet()){
            l.updatecount();
        }
    }

    private String printEmpty(Clause c){

        String result="";
        result+="emptyClause "+"("+problem.getLiteral(-c.getAssertionLiteral().getNumber()).toString()+"   "+c.getAssertionLiteral().toString()+")";
        return result;
    }

    private void backJumping(Clause c) { // salto all'indietro
        int minLevel=0;
        propagatedLiterals.clear();
        LinkedList<Literal> temp=new LinkedList<>();
        if(currentLevel==1 && !trace.getTrace().containsKey(0)){ //salto al livello 0
            for(Literal l:trace.getTrace().get(currentLevel)){
                l.setJustification(null);
                l.setState(0); //lo rendo indefinito
                if(!l.equals(problem.getLiteral(-c.getAssertionLiteral().getNumber())))
                    problem.getLiteral(-l.getNumber()).setJustification(null);
                problem.getLiteral(-l.getNumber()).setState(0);
                setFalseClauses(l);
                setFalseClauses(problem.getLiteral(-l.getNumber()));
            }
            trace.getTrace().clear(); // rimuovo tutto
            c.getAssertionLiteral().setState(1); // lo rendo vero
            temp.add(c.getAssertionLiteral());
            trace.getTrace().put(0,temp);
            currentLevel=0;
            satClauses(c.getAssertionLiteral());
            propagatedLiterals.add(setNegationLiteral(c.getAssertionLiteral()));
            propagationFlag=true;
            //temp.clear();
            return;
        }
        int levelToJump=currentLevel;
        if(trace.getTrace().containsKey(0)){
            minLevel=0;
        }
        else minLevel=1;
        //trovo il minimo livello a cui saltare
        int length=c.getSize();
        if(length==1 && currentLevel==0){
            System.out.println("INSODDISFACIBILE");
            //System.out.println("Numero di clausole imparate: "+numLearnedTot);
            //System.out.println("Numero di conflitti: "+numConflictTot);
            System.exit(0);
        }
        else if(length==1 && currentLevel!=0) levelToJump=0; //ho una clausola di conflitto unitaria, posso saltare al livello 0
        else{
            boolean find=false;
            for(int i=currentLevel-1;i>=minLevel;i--) { // parto dall'ultimo livello
                if(!find)
                    for (Literal l : trace.getTrace().get(i)) {
                        //trovo il minimo livello a cui saltare
                        if (!l.equals(problem.getLiteral(-c.getAssertionLiteral().getNumber())) && c.getSet().contains(problem.getLiteral(-l.getNumber()))) {
                            levelToJump = i;
                            find=true;
                            break;
                        }
                    }
            }
        }

        for(int i=currentLevel;i>levelToJump;i--) {
            for (Literal l : trace.getTrace().get(i)) {
                l.setJustification(null);
                l.setState(0); //lo rendo indefinito
                setFalseClauses(l);
                problem.getLiteral(-l.getNumber()).setState(0);
                if(!l.equals(problem.getLiteral(-c.getAssertionLiteral().getNumber())))
                    problem.getLiteral(-l.getNumber()).setJustification(null);
                setFalseClauses(problem.getLiteral(-l.getNumber()));
            }
            trace.getTrace().remove(i); // rimuovo il livello
        }

        temp=trace.getTrace().get(levelToJump);
        c.getAssertionLiteral().setState(1); // lo rendo vero
        if(temp!=null) {
            temp.add(c.getAssertionLiteral());
            trace.getTrace().remove(levelToJump);
            trace.getTrace().put(levelToJump, temp);
        }
        else{
            temp=new LinkedList<>();
            temp.add(c.getAssertionLiteral());
            trace.getTrace().put(levelToJump, temp);
        }
        currentLevel=levelToJump;
        satClauses(c.getAssertionLiteral());
        propagatedLiterals.add(setNegationLiteral(c.getAssertionLiteral()));
        propagationFlag=true;
        return;
    }

    private void setFalseClauses(Literal l){
        int count = 0;
        for (Clause c : problem.getSetC()) {
            if (c.getTrueLiterals().contains(l)) {
                c.getTrueLiterals().remove(l);
                c.getFalseLiterals().add(l);
                if (c.getTrueLiterals().size() == 0) {
                    c.setSatisfied(false);
                    problem.getSat().remove(c);
                    for (Literal lit : c.getWatchedLiterals()) {
                        lit.getWatchedList().remove(c);
                    }
                    c.getWatchedLiterals().clear();
                    count = 0;
                    while (count < 2) {
                        for (Literal l1 : c.getSet()) {
                            if (count < 2 && (l1.getState() == 0 || l1.getState() == 1)) {
                                c.getWatchedLiterals().add(l1);
                                l1.getWatchedList().add(c);
                                count++;
                            }
                        }
                        if (c.getWatchedLiterals().size() != 2) {
                            c.getWatchedLiterals().add(l);
                            l.getWatchedList().add(c);
                            count++;
                            for (Literal l3 : c.getFalseLiterals()) {
                                if (count < 2) {
                                    c.getWatchedLiterals().add(l3);
                                    l3.getWatchedList().add(c);
                                    count++;
                                }
                            }
                        }
                    }
                }
            }
            if (c.getSet().contains(l)) {
                c.getFalseLiterals().add(l);
            }
        }
    }

    private Clause explain(Clause c){
        level=currentLevel;
        Iterator<Literal> it=trace.getTrace().get(level).descendingIterator();
        Set<Literal> temp;
        for(Literal l:c.getSet()) {
            while (level >= 0) {
                while (it.hasNext()) {
                    Literal l1=it.next();
                    if (l1.getJustification()!=null && c.getSet().contains(problem.getLiteral(-l1.getNumber()))){
                        temp=resolution(c, l1);
                        problem.updateNumClausesTot();
                        Clause resolvent=new Clause(problem.getNumClausesTot(),temp);
                        if(!isAssertionClause(resolvent)){
                            for(Literal lit: resolvent.getWatchedLiterals())
                                lit.getWatchedList().remove(resolvent);
                        }
                        if(proof)
                            System.out.println(printResolution(c,l1,resolvent));
                        return resolvent;
                    }
                }
                level--;
            }
        }
        return null;
    }

    private Set<Literal> resolution(Clause c, Literal l1) {

            Set<Literal> result = new HashSet<>();
            for (Literal l : c.getSet()) {
                if (!l.equals(problem.getLiteral(-l1.getNumber()))) {
                    if (!result.contains(l)) result.add(l);
                }
            }
            for (Literal l2 : l1.getJustification().getSet()) {
                if (!l2.equals(l1))
                    if (!result.contains(l2)) result.add(l2);
            }
            return result;


    }

    private String printResolution(Clause conflict, Literal assortionLiteral, Clause resolvent){
        String result="";
        result+=resolvent.toString()+"("+conflict.toString()+"   "+assortionLiteral.getJustification().toString()+")";
        return result;
    }

    private String printModel(){
        int dimModello=0;
        String result="MODELLO: [";
        int min;
        if(trace.getTrace().containsKey(0)) min=0;
        else min=1;
        while(trace.getTrace().containsKey(min)){
            for(Literal l: trace.getTrace().get(min)){
                result+=l.toString()+" ";
                dimModello++;
            }
            min++;
        }
        result+="]\n";
        //result+="Dimensione modello: "+dimModello;
        return result;
    }
}
