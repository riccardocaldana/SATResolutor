import java.util.ArrayList;
import java.util.HashSet;

public class Test {
    private HashSet<Clause> setC;
    private HashSet<Clause> satC;
    private HashSet<Clause> remain;
    private Trace trace;
    private Problem problem;

    public Test(Problem problem){
        this.setC=new HashSet<>();
        this.satC=new HashSet<>();
        this.remain=new HashSet<>();
        this.problem=problem;
        this.remain.addAll(problem.getSetC());
        this.setC.addAll(problem.getSetC());//insieme clausole iniziali
    }

    public void setTrace(Trace trace) { //modello finale
        this.trace = trace;
    }

    public void sat(){
        int min;
        if(trace.getTrace().containsKey(0)) min=0;
        else min=1;
        ArrayList<Literal> traceList=new ArrayList<>();

        while(trace.getTrace().containsKey(min)){
            for(Literal l:trace.getTrace().get(min)){
                satClause(l);
                traceList.add(l);
            }
            min++;
        }
        if(remain.size()==0 && satC.size()== setC.size()){
            for(Literal literal:traceList){
                if(traceList.contains(problem.getLiteral(-literal.getNumber()))){
                    System.out.println("Errore");
                    System.out.println(literal.toString());
                    System.exit(1);
                }
            }
            System.out.println("Test corretto");
        }
    }

    private void satClause(Literal l){
        for(Clause c:setC){
            if(c.getSet().contains(l)){
                satC.add(c);
                remain.remove(c);
            }
        }
    }


}
