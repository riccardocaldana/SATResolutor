import java.util.HashMap;
import java.util.LinkedList;

public class Trace {
    HashMap<Integer,LinkedList<Literal>> trace;

    public Trace(){
        trace=new HashMap<>();
    }

    public HashMap<Integer, LinkedList<Literal>> getTrace() {
        return trace;
    }

    @Override
    public String toString() {
        String result="";
        Integer key=0;
        if(!trace.containsKey(0))
            key=1;
        while(trace.containsKey(key)){
            result+="Level "+Integer.toString(key)+": ";
            for(Literal l: trace.get(key)){
                result+=l.toString()+" ";
            }
            result+="\n";
            key=key+1;
        }
        return result;
    }
}
