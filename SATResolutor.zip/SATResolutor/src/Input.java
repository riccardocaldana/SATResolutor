import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Input {
    private File file;
    private Problem problem;
    public Input(File file){
        this.file=file;
        this.problem=new Problem();
    }

    public Problem getProblem() {
        return problem;
    }

    public void readFile(){
        Set<Literal> setL=new HashSet<>();
        Set<Clause> setC=new HashSet<>();
        try (Scanner scanner = new Scanner(file)) {
            String line=scanner.nextLine();
            String[] parts=line.split("\\s+");
            while(parts[0].equals("c")){
                line=scanner.nextLine();
                parts=line.split("\\s+");
            }
            if(parts[1].equals("cnf")){
                problem.setNumVariables(Integer.parseInt(parts[2]));
                problem.setNumClauses(Integer.parseInt(parts[3]));
                //creazione di tutti i letterali possibili
                Set<Literal> setTemp=new HashSet<>();
                for(int i=1;i<=problem.getNumVariables();i++){
                    setTemp.add(new Literal(i,0));
                    setTemp.add(new Literal(-i,0));
                }
                problem.setSetL(setTemp);
                int n;
                Boolean ans=true;
                for(int i=1;i<=problem.getNumClauses();i++){
                    while((n=scanner.nextInt())!=0 && (ans=scanner.hasNext())){
                        setL.add(problem.getLiteral(n));
                        problem.getLiteral(n).updatecount();
                        //problem.getLiteral(-n).updatecount();
                    }
                    if(!ans) setL.add(problem.getLiteral(n));
                    setC.add(new Clause(i,setL));
                    setL.clear();
                }
                problem.setSetC(setC);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Errore, file non trovato");
            System.exit(1);
        }
    }
}
